#!/bin/bash

# Скрипт запуска Telegram Business бота

echo "🚀 Запуск Telegram Business бота..."

# Проверка наличия Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 не найден. Установите Python 3.9 или выше."
    exit 1
fi

# Проверка наличия .env файла
if [ ! -f .env ]; then
    echo "⚠️  Файл .env не найден!"
    echo "Создайте файл .env на основе .env.example"
    echo ""
    echo "Пример:"
    echo "  cp .env.example .env"
    echo "  nano .env  # или используйте любой текстовый редактор"
    exit 1
fi

# Проверка зависимостей
echo "📦 Проверка зависимостей..."
if ! python3 -c "import aiogram" 2>/dev/null; then
    echo "⚠️  Зависимости не установлены!"
    echo "Устанавливаем зависимости..."
    pip3 install -r requirements.txt
fi

# Запуск бота
echo "✅ Всё готово! Запускаем бота..."
echo ""
python3 main.py
