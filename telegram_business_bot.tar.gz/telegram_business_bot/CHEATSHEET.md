# 📖 Шпаргалка

## 🚀 Команды запуска

```bash
# Проверка окружения
python check_environment.py

# Запуск бота
python main.py

# Linux/Mac - с правами
./run.sh

# Windows
run.bat

# Фоновый режим (Linux)
nohup python main.py &

# С логами
python main.py > bot.log 2>&1
```

---

## 🤖 Команды бота

```
/admin          - Открыть админ-панель
/start          - Приветствие (стандартная команда)
```

---

## 📦 Управление зависимостями

```bash
# Установка
pip install -r requirements.txt

# Установка с fast режимом
pip install aiogram[fast] apscheduler aiosqlite python-dotenv

# Обновление
pip install --upgrade -r requirements.txt

# Проверка установленных пакетов
pip list | grep -E 'aiogram|apscheduler|aiosqlite|python-dotenv'
```

---

## 🗄️ База данных

```bash
# Просмотр структуры
sqlite3 scenarios.db ".schema"

# Просмотр сценариев
sqlite3 scenarios.db "SELECT * FROM scenarios;"

# Подсчёт сценариев
sqlite3 scenarios.db "SELECT COUNT(*) FROM scenarios;"

# Удаление БД (сброс)
rm scenarios.db

# Backup
cp scenarios.db scenarios.db.backup
```

---

## 📝 Работа с .env

```bash
# Создание из примера
cp .env.example .env

# Редактирование
nano .env        # Linux
notepad .env     # Windows

# Проверка
cat .env         # Linux
type .env        # Windows

# Пример содержимого
BOT_TOKEN=1234567890:ABCdef...
ADMIN_IDS=123456789,987654321
```

---

## 🔍 Отладка

```bash
# Просмотр логов в реальном времени
tail -f bot.log

# Поиск ошибок в логах
grep ERROR bot.log
grep WARNING bot.log

# Последние 50 строк логов
tail -n 50 bot.log

# Очистка логов
> bot.log
```

---

## 📊 SQL запросы

### Просмотр сценариев

```sql
-- Все сценарии
SELECT * FROM scenarios;

-- Только активные
SELECT * FROM scenarios WHERE active = 1;

-- По типу триггера
SELECT * FROM scenarios WHERE trigger_type = 'contains';

-- С напоминаниями
SELECT * FROM scenarios WHERE is_reminder = 1;
```

### Подсчёт

```sql
-- Всего сценариев
SELECT COUNT(*) FROM scenarios;

-- Активных
SELECT COUNT(*) FROM scenarios WHERE active = 1;

-- По типам
SELECT trigger_type, COUNT(*) 
FROM scenarios 
GROUP BY trigger_type;
```

### Редактирование

```sql
-- Включить сценарий
UPDATE scenarios SET active = 1 WHERE id = 1;

-- Выключить сценарий
UPDATE scenarios SET active = 0 WHERE id = 1;

-- Изменить триггер
UPDATE scenarios 
SET trigger_value = 'новый триггер' 
WHERE id = 1;

-- Удалить сценарий
DELETE FROM scenarios WHERE id = 1;
```

---

## 🎯 Типы триггеров

| Тип | Описание | Пример триггера | Срабатывает на |
|-----|----------|-----------------|----------------|
| `exact` | Точная фраза | `привет` | "привет", "Привет" |
| `contains` | Содержит | `цена` | "какая цена?", "узнать цены" |
| `callback` | Кнопка | `schedule_full` | callback_data кнопки |

---

## ⌨️ HTML форматирование

```html
<b>Жирный</b>
<i>Курсив</i>
<u>Подчёркнутый</u>
<code>Моноширинный</code>
<pre>Код блок</pre>
<a href="https://example.com">Ссылка</a>
<s>Зачёркнутый</s>
```

**Пример:**
```html
<b>💰 Наши цены:</b>

<i>Консультация:</i> 2000₽
<i>Процедура:</i> 5000₽

<a href="https://example.com">Подробнее на сайте</a>
```

---

## 🔔 Напоминания

| Время | Минуты |
|-------|--------|
| 1 минута | 1 |
| 5 минут | 5 |
| 15 минут | 15 |
| 30 минут | 30 |
| 1 час | 60 |
| 2 часа | 120 |
| 6 часов | 360 |
| 12 часов | 720 |
| 24 часа (сутки) | 1440 |
| 2 дня | 2880 |
| 3 дня | 4320 |
| 7 дней (неделя) | 10080 |

---

## 📱 Эмодзи категории

### Контакты
```
📞 ☎️ 📧 📨 📩 💌 📮 📪 📫 📬
📭 📍 📌 🗺️ 🌐 🔗 📱 📲 💻
```

### Деньги
```
💰 💵 💴 💶 💷 💸 💳 💎 🪙
```

### Время
```
⏰ ⏱️ ⏲️ ⌚ 🕐 🕑 🕒 🕓 🕔 🕕 
🕖 🕗 🕘 🕙 🕚 🕛
```

### Статусы
```
✅ ❌ ⚠️ ℹ️ 🔔 📢 📣 ⭐ 🌟 ✨
🔥 💡 🎯 🎉 🎊 🎁 🎈
```

### Стрелки
```
➡️ ⬅️ ⬆️ ⬇️ ↗️ ↘️ ↙️ ↖️ ⤴️ ⤵️
🔄 🔃 🔀 🔁 🔂
```

### Символы
```
❤️ 💚 💙 💜 🧡 💛 🤍 🖤 🤎
👍 👎 👏 🙏 🤝 ✊ 👊 🤜 🤛
```

---

## 🔧 Git команды

```bash
# Инициализация
git init
git add .
git commit -m "Initial commit"

# Сохранение изменений
git add .
git commit -m "Описание изменений"
git push

# Обновление
git pull

# Проверка статуса
git status

# История коммитов
git log --oneline

# Отмена изменений
git checkout -- файл
```

---

## 🐳 Docker (опционально)

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
CMD ["python", "main.py"]
```

```bash
# Сборка
docker build -t telegram-business-bot .

# Запуск
docker run -d --name bot telegram-business-bot

# Логи
docker logs -f bot

# Остановка
docker stop bot
```

---

## 🔐 Безопасность

```bash
# Права на .env (только владелец может читать)
chmod 600 .env

# Права на скрипты
chmod +x run.sh
chmod +x check_environment.py

# Проверка прав
ls -la .env
```

---

## 📦 Termux (Android)

```bash
# Установка
pkg update && pkg upgrade
pkg install python git

# Предотвращение засыпания
termux-wake-lock

# Работа в фоне
nohup python main.py &

# Просмотр процессов
ps aux | grep python

# Остановка
pkill -f main.py
```

---

## 🚨 Частые ошибки

### `ModuleNotFoundError: No module named 'aiogram'`
```bash
pip install aiogram
```

### `ValueError: BOT_TOKEN не найден`
```bash
# Проверьте .env файл
cat .env
```

### `sqlite3.OperationalError: database is locked`
```bash
# Закройте все подключения к БД
pkill -f main.py
rm scenarios.db-journal  # если есть
```

### `Unauthorized: bot token is invalid`
```bash
# Проверьте токен в .env
# Получите новый токен у @BotFather
```

---

## 📞 Полезные ссылки

- [@BotFather](https://t.me/BotFather) - создание бота
- [@userinfobot](https://t.me/userinfobot) - получение ID
- [aiogram docs](https://docs.aiogram.dev/)
- [Telegram Bot API](https://core.telegram.org/bots/api)

---

## 💡 Советы

1. **Делайте backup БД** перед обновлениями
2. **Используйте "Содержит слово"** для гибкости
3. **Добавляйте эмодзи** для красоты
4. **Тестируйте сценарии** перед запуском
5. **Читайте логи** при проблемах

---

## 🎓 Обучение

1. Начните с **QUICKSTART.md**
2. Изучите **EXAMPLES.md**
3. Прочитайте **SETUP.md**
4. Смотрите **API.md** для расширения

---

<div align="center">

**Нужна помощь?** → [SETUP.md](SETUP.md) (раздел "Решение проблем")

</div>
